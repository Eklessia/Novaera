package com.example.novaera

import org.junit.Test


class ExampleUnitTest {

    @Test
    fun GetidProductos() {
        val num = 1


    }

}